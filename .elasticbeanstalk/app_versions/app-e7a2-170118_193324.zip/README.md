# react

https://waffle.io/Tunell/react

cd to the correct folder.

##to install:

npm install

mkdir target

##To run:

npm start

##To Build:

webpack