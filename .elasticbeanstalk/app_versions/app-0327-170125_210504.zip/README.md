# react

u

cd to the correct folder.

##to install:

npm install

mkdir target

##To run:

npm start

##To Build:

webpack

##Live server:
http://node-express-env.z7h53zphpv.us-west-2.elasticbeanstalk.com/